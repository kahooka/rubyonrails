require 'rails_helper'

RSpec.describe IdeasController, type: :controller do

end
