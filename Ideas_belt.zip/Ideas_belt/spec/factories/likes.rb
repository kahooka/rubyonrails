FactoryGirl.define do
  factory :like do
    user nil
    idea nil
  end
end
