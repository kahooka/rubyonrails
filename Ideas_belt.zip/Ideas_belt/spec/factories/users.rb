FactoryGirl.define do
  factory :user do
    password ""
    email "MyString"
    name "MyString"
    dob "2017-12-23"
  end
end
