Test logins: 

    email: darth@darth.com
    password: password

    email: bob@bob.com
    password: password


Video link: https://youtu.be/C4nnjwyAesw

Deployed IP: 18.221.128.47


